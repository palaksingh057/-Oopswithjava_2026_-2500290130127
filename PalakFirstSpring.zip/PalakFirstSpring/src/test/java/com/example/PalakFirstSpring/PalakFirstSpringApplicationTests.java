package com.example.PalakFirstSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PalakFirstSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
