
package com.kiet.library.service;

import com.kiet.library.model.Book;
import com.kiet.library.repository.BookRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    // Get all books
    public List<Book> getAllBooks() {
        return bookRepository.getAllBooks();
    }

    // Get book by ID
    public Optional<Book> getBookById(int bookId) {
        try {
            return Optional.ofNullable(
                bookRepository.getBookById(bookId)
            );
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    // Add a new book
    public Book addBook(Book book) {
        int result = bookRepository.addBook(book);
        return result > 0 ? book : null;
    }

    // Update a book
    public Optional<Book> updateBook(int bookId, Book updatedBook) {
        updatedBook.setBookId(bookId);

        int result = bookRepository.updateBook(updatedBook);

        if (result > 0) {
            return Optional.of(updatedBook);
        }

        return Optional.empty();
    }

    // Delete a book
    public boolean deleteBook(int bookId) {
        return bookRepository.deleteBook(bookId) > 0;
    }

    // Search books by category
    public List<Book> searchByCategory(String category) {
        return bookRepository.searchByCategory(category);
    }

    // Find books published from a particular year
    public List<Book> findPublishedFromYear(int fromYear) {
        return bookRepository.findPublishedFromYear(fromYear);
    }
}
