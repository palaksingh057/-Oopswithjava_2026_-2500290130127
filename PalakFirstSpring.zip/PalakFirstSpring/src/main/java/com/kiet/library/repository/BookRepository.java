
package com.kiet.library.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.kiet.library.model.Book;

@Repository
public class BookRepository {

    @Autowired
    private JdbcTemplate jdbc;

    private RowMapper<Book> rowMapper = (rs, rowNum) -> {
        Book book = new Book();

        book.setBookId(rs.getInt("id"));
        book.setTitle(rs.getString("title"));
        book.setAuthor(rs.getString("author"));
        book.setCategory(rs.getString("category"));
        book.setPublicationYear(rs.getInt("publication_year"));
        book.setAvailable(rs.getBoolean("available"));

        return book;
    };

    // Get all books
    public List<Book> getAllBooks() {
        String sql = "SELECT * FROM books";
        return jdbc.query(sql, rowMapper);
    }

    // Get book by ID
    public Book getBookById(int bookId) {
        String sql = "SELECT * FROM books WHERE id = ?";
        return jdbc.queryForObject(sql, rowMapper, bookId);
    }

    // Add book
    public int addBook(Book book) {
        String sql = "INSERT INTO books " +
                "(title, author, category, publication_year, available) " +
                "VALUES (?, ?, ?, ?, ?)";

        return jdbc.update(
                sql,
                book.getTitle(),
                book.getAuthor(),
                book.getCategory(),
                book.getPublicationYear(),
                book.isAvailable()
        );
    }

    // Update book
    public int updateBook(Book book) {
        String sql = "UPDATE books SET title = ?, author = ?, " +
                "category = ?, publication_year = ?, available = ? " +
                "WHERE id = ?";

        return jdbc.update(
                sql,
                book.getTitle(),
                book.getAuthor(),
                book.getCategory(),
                book.getPublicationYear(),
                book.isAvailable(),
                book.getBookId()
        );
    }

    // Delete book
    public int deleteBook(int bookId) {
        String sql = "DELETE FROM books WHERE id = ?";
        return jdbc.update(sql, bookId);
    }

    // Search by category
    public List<Book> searchByCategory(String category) {
        String sql = "SELECT * FROM books WHERE category = ?";
        return jdbc.query(sql, rowMapper, category);
    }

    // Find books published from a given year
    public List<Book> findPublishedFromYear(int fromYear) {
        String sql = "SELECT * FROM books WHERE publication_year >= ?";
        return jdbc.query(sql, rowMapper, fromYear);
    }
}

