
package com.kiet.library.student.controller;

import com.kiet.library.student.model.Student;
import com.kiet.library.student.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    // Add student
    @PostMapping
    public ResponseEntity<?> addStudent(@RequestBody Student student) {
        try {
            return ResponseEntity.ok(
                    studentService.addStudent(student));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Get all students
    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    // Search by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getStudentById(@PathVariable int id) {
        Student student = studentService.getStudentById(id);

        if (student == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(student);
    }

    // Search by email
    @GetMapping("/search/email")
    public ResponseEntity<?> getStudentByEmail(
            @RequestParam String email) {

        Student student = studentService.getStudentByEmail(email);

        if (student == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(student);
    }

    // Search by course
    @GetMapping("/search/course")
    public List<Student> getStudentsByCourse(
            @RequestParam String course) {

        return studentService.getStudentsByCourse(course);
    }

    // Merit list
    @GetMapping("/merit-list")
    public List<Student> getMeritList() {
        return studentService.getMeritList();
    }

    // Students with same skills
    @GetMapping("/same-skills")
    public Object getStudentsWithSameSkills() {
        return studentService.getStudentsWithSameSkills();
    }

    // Programming improvement list
    @GetMapping("/programming-improvement")
    public List<Student> getProgrammingImprovementStudents() {
        return studentService.getProgrammingImprovementStudents();
    }

    // Update scores and skills
    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(
            @PathVariable int id,
            @RequestBody Student student) {

        try {
            return ResponseEntity.ok(
                    studentService.updateStudent(id, student));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Delete student
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable int id) {
        try {
            return ResponseEntity.ok(
                    studentService.deleteStudent(id));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}

