

package com.kiet.library.student.service;

import com.kiet.library.student.model.Student;
import com.kiet.library.student.repository.StudentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // Calculate average
    public double calculateAverage(Student student) {
        return (student.getProgrammingScore()
                + student.getMathematicsScore()) / 2.0;
    }

    // Performance category
    public String getPerformanceCategory(Student student) {
        double average = calculateAverage(student);

        if (average >= 85) return "Excellent";
        else if (average >= 70) return "Good";
        else if (average >= 50) return "Satisfactory";
        else return "Needs Improvement";
    }

    // Stronger subject
    public String getStrongerSubject(Student student) {
        if (student.getProgrammingScore() >
                student.getMathematicsScore()) {
            return "Programming";
        } else if (student.getMathematicsScore() >
                student.getProgrammingScore()) {
            return "Mathematics";
        }
        return "Both subjects are equal";
    }

    // Validate student
    private void validateStudent(Student student) {
        if (student == null) {
            throw new IllegalArgumentException("Student cannot be null");
        }

        if (student.getStudentId() <= 0) {
            throw new IllegalArgumentException("Invalid Student ID");
        }

        if (student.getStudentName() == null ||
                student.getStudentName().isBlank()) {
            throw new IllegalArgumentException("Student name is required");
        }

        if (student.getEmail() == null ||
                student.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }

        if (student.getProgrammingScore() < 0 ||
                student.getProgrammingScore() > 100 ||
                student.getMathematicsScore() < 0 ||
                student.getMathematicsScore() > 100) {
            throw new IllegalArgumentException(
                    "Scores must be between 0 and 100");
        }
    }

    // Add student
    public String addStudent(Student student) {
        validateStudent(student);

        if (studentRepository.getStudentById(
                student.getStudentId()) != null) {
            throw new IllegalArgumentException("Student ID already exists");
        }

        if (studentRepository.getStudentByEmail(
                student.getEmail()) != null) {
            throw new IllegalArgumentException("Email already exists");
        }

        studentRepository.addStudent(student);
        studentRepository.addSkills(
                student.getStudentId(),
                student.getTechnicalSkills());

        return "Student added successfully";
    }

    // Get all students
    public List<Student> getAllStudents() {
        return studentRepository.getAllStudents();
    }

    // Search by ID
    public Student getStudentById(int id) {
        return studentRepository.getStudentById(id);
    }

    // Search by email
    public Student getStudentByEmail(String email) {
        return studentRepository.getStudentByEmail(email);
    }

    // Search by course
    public List<Student> getStudentsByCourse(String course) {
        return studentRepository.getStudentsByCourse(course);
    }

    // Merit list
    public List<Student> getMeritList() {
        List<Student> students = getAllStudents();

        students.sort(Comparator.comparingDouble(
                this::calculateAverage).reversed());

        return students;
    }

    // Programming improvement needed, Mathematics >= 75
    public List<Student> getProgrammingImprovementStudents() {
        return getAllStudents().stream()
                .filter(s -> s.getProgrammingScore() < 50
                        && s.getMathematicsScore() >= 75)
                .toList();
    }

    // Find students having same technical skills
    public Map<List<String>, List<Student>> getStudentsWithSameSkills() {
        Map<List<String>, List<Student>> result = new HashMap<>();

        for (Student student : getAllStudents()) {
            List<String> skills = student.getTechnicalSkills();

            List<String> key = skills == null
                    ? new ArrayList<>()
                    : new ArrayList<>(skills);

            Collections.sort(key);

            result.computeIfAbsent(key, k -> new ArrayList<>())
                    .add(student);
        }

        result.entrySet().removeIf(
                entry -> entry.getValue().size() < 2);

        return result;
    }

    // Update scores and skills
    public String updateStudent(int id, Student updatedStudent) {
        validateStudent(updatedStudent);

        Student existing = getStudentById(id);

        if (existing == null) {
            throw new IllegalArgumentException("Student not found");
        }

        if (updatedStudent.getStudentId() != id) {
            throw new IllegalArgumentException("Student ID cannot be changed");
        }

        studentRepository.updateScores(
                id,
                updatedStudent.getProgrammingScore(),
                updatedStudent.getMathematicsScore());

        studentRepository.updateSkills(
                id,
                updatedStudent.getTechnicalSkills());

        return "Student updated successfully";
    }

    // Delete student
    public String deleteStudent(int id) {
        if (getStudentById(id) == null) {
            throw new IllegalArgumentException("Student not found");
        }

        studentRepository.deleteStudent(id);
        return "Student deleted successfully";
    }
}

