
package com.kiet.library.student.repository;

import com.kiet.library.student.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class StudentRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Add student
    public int addStudent(Student student) {

        String sql = "INSERT INTO students " +
                "(student_id, student_name, email, course_name, programming_score, mathematics_score) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        return jdbcTemplate.update(sql,
                student.getStudentId(),
                student.getStudentName(),
                student.getEmail(),
                student.getCourseName(),
                student.getProgrammingScore(),
                student.getMathematicsScore());
    }

    // Add technical skills
    public void addSkills(int studentId, List<String> skills) {

        String sql = "INSERT INTO student_skills (student_id, skill_name) VALUES (?, ?)";

        if (skills != null) {
            for (String skill : skills) {
                jdbcTemplate.update(sql, studentId, skill);
            }
        }
    }

    // Get skills
    public List<String> getSkills(int studentId) {

        String sql = "SELECT skill_name FROM student_skills WHERE student_id = ?";

        return jdbcTemplate.query(sql,
                (rs, rowNum) -> rs.getString("skill_name"),
                studentId);
    }

    // Get all students
    public List<Student> getAllStudents() {

        String sql = "SELECT * FROM students";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Student student = new Student();

            student.setStudentId(rs.getInt("student_id"));
            student.setStudentName(rs.getString("student_name"));
            student.setEmail(rs.getString("email"));
            student.setCourseName(rs.getString("course_name"));
            student.setProgrammingScore(rs.getDouble("programming_score"));
            student.setMathematicsScore(rs.getDouble("mathematics_score"));
            student.setTechnicalSkills(getSkills(student.getStudentId()));

            return student;
        });
    }

    // Search student by ID
    public Student getStudentById(int studentId) {

        String sql = "SELECT * FROM students WHERE student_id = ?";

        List<Student> students = jdbcTemplate.query(sql, (rs, rowNum) -> {
            Student student = new Student();

            student.setStudentId(rs.getInt("student_id"));
            student.setStudentName(rs.getString("student_name"));
            student.setEmail(rs.getString("email"));
            student.setCourseName(rs.getString("course_name"));
            student.setProgrammingScore(rs.getDouble("programming_score"));
            student.setMathematicsScore(rs.getDouble("mathematics_score"));
            student.setTechnicalSkills(getSkills(studentId));

            return student;
        }, studentId);

        return students.isEmpty() ? null : students.get(0);
    }

    // Search student by email
    public Student getStudentByEmail(String email) {

        String sql = "SELECT student_id FROM students WHERE email = ?";

        List<Integer> ids = jdbcTemplate.query(sql,
                (rs, rowNum) -> rs.getInt("student_id"), email);

        return ids.isEmpty() ? null : getStudentById(ids.get(0));
    }

    // Search students by course
    public List<Student> getStudentsByCourse(String courseName) {

        String sql = "SELECT student_id FROM students WHERE course_name = ?";

        List<Integer> ids = jdbcTemplate.query(sql,
                (rs, rowNum) -> rs.getInt("student_id"), courseName);

        List<Student> students = new ArrayList<>();

        for (int id : ids) {
            students.add(getStudentById(id));
        }

        return students;
    }

    // Update scores
    public int updateScores(int studentId,
                            double programmingScore,
                            double mathematicsScore) {

        String sql = "UPDATE students SET programming_score = ?, mathematics_score = ? WHERE student_id = ?";

        return jdbcTemplate.update(sql,
                programmingScore, mathematicsScore, studentId);
    }

    // Delete old skills
    public void deleteSkills(int studentId) {

        String sql = "DELETE FROM student_skills WHERE student_id = ?";
        jdbcTemplate.update(sql, studentId);
    }

    // Update skills
    public void updateSkills(int studentId, List<String> skills) {

        deleteSkills(studentId);
        addSkills(studentId, skills);
    }

    // Delete student
    public int deleteStudent(int studentId) {

        String sql = "DELETE FROM students WHERE student_id = ?";
        return jdbcTemplate.update(sql, studentId);
    }
}
