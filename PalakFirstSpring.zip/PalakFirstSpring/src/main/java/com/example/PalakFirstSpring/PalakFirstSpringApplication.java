package com.example.PalakFirstSpring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.kiet.library.LibraryApplication;

@SpringBootApplication
public class PalakFirstSpringApplication implements CommandLineRunner {

    @Autowired
    studentapplication sa;

    public static void main(String[] args) {
        //SpringApplication.run(PalakFirstSpringApplication.class, args);
        ConfigurableApplicationContext context =
                SpringApplication.run(LibraryApplication.class, args);

        System.out.println("Total Beans Count: "
                + context.getBeanDefinitionCount());
        String[] names = context.getBeanDefinitionNames();
        for (String name : names) {
            System.out.println(name);
        }
    }

    @Override
    public void run(String... args) throws Exception {
       System.out.println( sa.display());
    }
}